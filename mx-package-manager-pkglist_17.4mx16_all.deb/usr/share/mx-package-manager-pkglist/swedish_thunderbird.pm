<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Swedish_Thunderbird
</name>

<description>  
Swedish localisation of Thunderbird
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-xpi-sv-se 
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-xpi-sv-se 
</uninstall_package_names>
</app>