<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Catalan_Libreoffice
</name>

<description>  
Catalan LibreOffice Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
libreoffice-draw     
libreoffice-impress 
libreoffice-math
libreoffice-writer
libreoffice-l10n-ca
libreoffice-help-ca
libreoffice-gtk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
libreoffice-draw     
libreoffice-impress 
libreoffice-math
libreoffice-writer
libreoffice-l10n-ca
libreoffice-help-ca
libreoffice-gtk
</uninstall_package_names>
</app>