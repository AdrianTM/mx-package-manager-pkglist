<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Basque_Firefox
</name>

<description>  
Basque localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-eu
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-eu
</uninstall_package_names>
</app>