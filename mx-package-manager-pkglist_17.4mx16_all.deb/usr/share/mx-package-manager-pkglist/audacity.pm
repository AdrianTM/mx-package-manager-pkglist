<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>  
Audacity
</name>

<description>  
a multi-track audio editor
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/010/385/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
audacity
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
audacity
</uninstall_package_names>
</app>