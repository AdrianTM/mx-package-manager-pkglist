<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Farsi_Firefox
</name>

<description>  
Farsi localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-fa
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-fa
</uninstall_package_names>
</app>