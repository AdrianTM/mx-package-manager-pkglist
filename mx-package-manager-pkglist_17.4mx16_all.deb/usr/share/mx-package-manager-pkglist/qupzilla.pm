<?xml version="1.0"?>
<app>

<category>
Browser
</category>

<name>  
Qupzilla
</name>

<description>  
Latest Qupzilla lightweight browser
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/301/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
qupzilla
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
qupzilla
</uninstall_package_names>
</app>