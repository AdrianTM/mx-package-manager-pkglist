<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Swedish
</name>

<description>  
Swedish Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-sv
      myspell-sv-se
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-sv
      myspell-sv-se
</uninstall_package_names>
</app>