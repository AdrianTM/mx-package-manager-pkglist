<?xml version="1.0"?>
<app>

<category>
Torrent
</category>

<name>  
rTorrent
</name>

<description>  
an ncurses BitTorrent client
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/001/284/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
rtorrent
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
rtorrent
</uninstall_package_names>
</app>