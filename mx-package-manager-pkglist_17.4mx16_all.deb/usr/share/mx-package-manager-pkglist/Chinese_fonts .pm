<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Chinese_fonts 
</name>

<description>  
Chinese fonts packages
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
xfonts-wqy	
ttf-freefont
ttf-wqy-zenhei
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
xfonts-wqy	
ttf-freefont
ttf-wqy-zenhei
</uninstall_package_names>
</app>