<?xml version="1.0"?>
<app>

<category>
Window Managers
</category>

<name>  
MATE
</name>

<description>  
basic install of MATE desktop
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/010/990/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
mate-core
mate-desktop-environment
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
mate-core
mate-desktop-environment
</uninstall_package_names>
</app>