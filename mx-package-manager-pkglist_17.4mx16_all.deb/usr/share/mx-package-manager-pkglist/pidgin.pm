<?xml version="1.0"?>
<app>

<category>
Messaging
</category>

<name>  
Pidgin
</name>

<description>  
an easy to use and free chat client
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/009/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
pidgin
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pidgin
</uninstall_package_names>
</app>