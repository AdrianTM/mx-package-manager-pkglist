<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Bulgarian_Firefox
</name>

<description>  
Bulgarian localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-bg
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-bg
</uninstall_package_names>
</app>