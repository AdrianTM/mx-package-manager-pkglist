<?xml version="1.0"?>
<app>

<category>
Utility
</category>

<name>  
Streamlight
</name>

<description>  
View Youtube Videos outside the browser by selecting links
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
streamlight-antix
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
streamlight-antix
</uninstall_package_names>
</app>