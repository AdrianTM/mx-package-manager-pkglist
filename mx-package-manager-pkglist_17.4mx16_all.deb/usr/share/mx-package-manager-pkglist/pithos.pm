<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>  
Pithos
</name>

<description>  
a native Pandora Radio client
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/199/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
pithos
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pithos
</uninstall_package_names>
</app>