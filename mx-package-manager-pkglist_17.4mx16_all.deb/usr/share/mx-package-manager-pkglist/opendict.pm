<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>  
Dictionary
</name>

<description>  
OpenDict Dictionary
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
opendict
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
opendict
</uninstall_package_names>
</app>