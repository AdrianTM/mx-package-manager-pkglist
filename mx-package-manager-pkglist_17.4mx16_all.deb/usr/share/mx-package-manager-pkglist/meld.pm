<?xml version="1.0"?>
<app>

<category>
Development
</category>

<name>  
Meld
</name>

<description>  
graphical tool to diff and merge files
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/005/098/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
meld
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
meld
</uninstall_package_names>
</app>