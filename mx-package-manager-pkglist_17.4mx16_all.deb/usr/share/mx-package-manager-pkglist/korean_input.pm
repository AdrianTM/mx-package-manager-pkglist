<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Korean_Input
</name>

<description>  
Korean Fonts and ibus
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
ttf-alee
	fonts-baekmuk
	im-config
        ibus-hangul 
        ibus-qt4 
        ibus-gtk3
        python-appindicator
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
ttf-alee
	fonts-baekmuk
	im-config
        ibus-hangul 
        ibus-qt4 
        ibus-gtk3
        python-appindicator
</uninstall_package_names>
</app>