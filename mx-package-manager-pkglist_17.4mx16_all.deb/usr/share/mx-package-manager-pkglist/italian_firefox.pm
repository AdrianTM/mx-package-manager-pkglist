<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Italian_Firefox
</name>

<description>  
Italian localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-it 
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-it 
</uninstall_package_names>
</app>