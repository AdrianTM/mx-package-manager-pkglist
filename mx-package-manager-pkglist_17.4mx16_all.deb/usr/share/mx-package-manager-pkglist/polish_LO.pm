<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Polish_Libreoffice
</name>

<description>  
Polish Language Meta-Package for LibreOffice
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
        libreoffice-draw     
        libreoffice-impress 
        libreoffice-math
        libreoffice-writer
	libreoffice-l10n-pl
	libreoffice-help-pl
        libreoffice-gtk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
        libreoffice-draw     
        libreoffice-impress 
        libreoffice-math
        libreoffice-writer
	libreoffice-l10n-pl
	libreoffice-help-pl
        libreoffice-gtk
</uninstall_package_names>
</app>