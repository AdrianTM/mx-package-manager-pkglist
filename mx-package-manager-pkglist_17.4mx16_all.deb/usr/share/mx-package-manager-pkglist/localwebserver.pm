<?xml version="1.0"?>
<app>

<category>
Server
</category>

<name>  
Local Web Server
</name>

<description>  
apache2, php5, mysql server applications
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
apache2
apache2-utils
apache2-mpm-prefork
php5 
php5-common
mysql-server
mysql-common
libapache2-mod-php5
php5-mysql
phpmyadmin 
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
apache2
apache2-utils
apache2-mpm-prefork
php5 
php5-common
mysql-server
mysql-common
libapache2-mod-php5
php5-mysql
phpmyadmin
</uninstall_package_names>
</app>