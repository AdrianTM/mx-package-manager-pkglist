<?xml version="1.0"?>
<app>

<category>
Remote Access
</category>

<name>  
Remmina
</name>

<description>  
a remote desktop client supporting vnc & rdp
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/011/154/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
remmina
remmina-plugin-vnc
remmina-plugin-rdp
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
remmina
remmina-plugin-vnc
remmina-plugin-rdp
</uninstall_package_names>
</app>