<?xml version="1.0"?>
<app>

<category>
Remote Access
</category>

<name>  
1-to-1 Assistance
</name>

<description>  
Remote access help app from antiX
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
1-to-1-assistance-antix
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
1-to-1-assistance-antix
</uninstall_package_names>
</app>