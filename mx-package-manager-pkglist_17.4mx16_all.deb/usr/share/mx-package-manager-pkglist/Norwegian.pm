<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Norwegian
</name>

<description>  
Norwegian Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-no
      myspell-nb
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-no
      myspell-nb
</uninstall_package_names>
</app>