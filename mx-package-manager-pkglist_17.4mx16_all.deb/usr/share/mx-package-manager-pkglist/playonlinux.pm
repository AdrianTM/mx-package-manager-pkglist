<?xml version="1.0"?>
<app>

<category>
Games
</category>

<name>  
Play on Linux
</name>

<description>  
Play on Linux 
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/063/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
wine-staging
wine-staging-compat
playonlinux
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
wine-staging
wine-staging-compat
playonlinux
</uninstall_package_names>
</app>