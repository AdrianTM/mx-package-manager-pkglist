<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Serbian_Thunderbird
</name>

<description>  
Serbian localisation of Thunderbird
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-xpi-sr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-xpi-sr
</uninstall_package_names>
</app>