<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Russian_Thunderbird
</name>

<description>  
Russian localisation of Thunderbird
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-xpi-ru
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-xpi-ru
</uninstall_package_names>
</app>