<?xml version="1.0"?>
<app>

<category>
Media Converter
</category>

<name>  
Handbrake
</name>

<description>  
versatile DVD ripper and video transcoder (cli and GUI)
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/720/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
handbrake
handbrake-cli
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
handbrake
handbrake-cli
</uninstall_package_names>
</app>