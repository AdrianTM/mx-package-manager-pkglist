<?xml version="1.0"?>
<app>


<category>
Screencast
</category>

<name>  
recordmydesktop
</name>

<description>  
a desktop session recorder
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/002/274/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gtk-recordmydesktop
recordmydesktop
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gtk-recordmydesktop
recordmydesktop
</uninstall_package_names>

</app>
