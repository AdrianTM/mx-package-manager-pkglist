<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>  
Inkscape
</name>

<description>  
a vector-based drawing program
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/295/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
inkscape
aspell
imagemagick
libwmf-bin
perlmagick
pstoedit
python-lxml
python-numpy
transfig
libgnomevfs2-extra
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
inkscape
</uninstall_package_names>
</app>