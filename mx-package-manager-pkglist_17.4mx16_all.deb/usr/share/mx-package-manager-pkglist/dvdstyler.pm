<?xml version="1.0"?>
<app>

<category>
Video
</category>

<name>  
DVDStyler
</name>

<description>  
DVD authoring application for the creation of professional-looking DVDs
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/008/331/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
dvdstyler
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
dvdstyler
</uninstall_package_names>
</app>