<?xml version="1.0"?>
<app>

<category>
Browser
</category>

<name>  
Firefox
</name>

<description>  
Latest Firefox
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/721/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox
</uninstall_package_names>
</app>