<?xml version="1.0"?>
<app>

<category>
Window Managers
</category>

<name>  
IceWM
</name>

<description>  
lightweight environment 
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/088/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
icewm
icewm-common
icewm-themes-antix
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
icewm
icewm-common
icewm-themes-antix
</uninstall_package_names>
</app>