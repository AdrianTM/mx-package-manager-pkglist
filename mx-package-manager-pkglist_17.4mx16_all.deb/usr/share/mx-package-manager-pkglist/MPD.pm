<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>  
MPD Music Player Daemon
</name>

<description>  
a flexible, powerful, server-side application for playing music
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/004/889/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
mpd
mpc
mpdscribble
ncmpcpp
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
mpd
mpc
mpdscribble
ncmpcpp
</uninstall_package_names>
</app>