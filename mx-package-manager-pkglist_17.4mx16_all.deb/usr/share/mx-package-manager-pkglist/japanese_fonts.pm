<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Japanese_Fonts
</name>

<description>  
Japanese fonts packages
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
fonts-vlgothic
	fonts-takao-gothic
	fonts-takao-mincho
	fonts-ipafont-gothic
	fonts-ipafont-mincho
	fonts-ipaexfont-gothic
	fonts-ipaexfont-mincho
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
fonts-vlgothic
	fonts-takao-gothic
	fonts-takao-mincho
	fonts-ipafont-gothic
	fonts-ipafont-mincho
	fonts-ipaexfont-gothic
	fonts-ipaexfont-mincho
</uninstall_package_names>
</app>