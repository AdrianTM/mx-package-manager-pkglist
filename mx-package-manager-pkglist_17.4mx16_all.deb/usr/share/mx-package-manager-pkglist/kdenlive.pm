<?xml version="1.0"?>
<app>

<category>
Video
</category>

<name>  
Kdenlive
</name>

<description>  
the KDE video editor
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/004/462/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
kdenlive
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
kdenlive
</uninstall_package_names>
</app>