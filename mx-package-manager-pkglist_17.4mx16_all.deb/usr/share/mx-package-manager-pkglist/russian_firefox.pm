<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Russian_Firefox
</name>

<description>  
Russian localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-ru
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-ru
</uninstall_package_names>
</app>