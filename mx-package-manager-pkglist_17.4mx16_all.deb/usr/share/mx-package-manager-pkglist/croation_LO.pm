<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Croatian_Libreoffice
</name>

<description>  
Croatian LibreOffice Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
libreoffice-draw     
libreoffice-impress 
libreoffice-math
libreoffice-writer
libreoffice-l10n-hr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
libreoffice-draw     
libreoffice-impress 
libreoffice-math
libreoffice-writer
libreoffice-l10n-hr
</uninstall_package_names>
</app>