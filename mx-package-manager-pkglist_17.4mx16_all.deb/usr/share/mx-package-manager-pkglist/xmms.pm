<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>  
XMMS
</name>

<description>  
multimedia player modelled on winamp
</description>

<installable>
all
</installable>

<screenshot>http://www.xmms.org/screenshots/main.gif</screenshot>

<preinstall>

</preinstall>

<install_package_names>
xmms
xmms-plugins-antix
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
audacity
</uninstall_package_names>
</app>