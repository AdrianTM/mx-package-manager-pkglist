<?xml version="1.0"?>
<app>

<category>
Media Converter
</category>

<name>  
Arista
</name>

<description>  
a python based simple multimedia transcoder
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/004/665/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
arista
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
arista
</uninstall_package_names>
</app>