<?xml version="1.0"?>
<app>

<category>
FileManagers
</category>

<name>  
SpaceFM
</name>

<description>  
a multi-panel tabbed file and desktop manager offering stability, speed, convenience and flexibility
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/593/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
spacefm
udevil
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
spacefm
</uninstall_package_names>
</app>