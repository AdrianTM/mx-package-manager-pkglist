<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Latvian_Firefox
</name>

<description>  
Latvian localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-lv
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-lv
</uninstall_package_names>
</app>