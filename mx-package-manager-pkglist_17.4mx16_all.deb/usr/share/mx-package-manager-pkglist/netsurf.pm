<?xml version="1.0"?>
<app>

<category>
Browser
</category>

<name>  
Netsurf
</name>

<description>  
Latest Netsurf Browser
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
netsurf
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
netsurf
</uninstall_package_names>
</app>