<?xml version="1.0"?>
<app>

<category>
Video
</category>

<name>  
Openshot
</name>

<description>  
non-linear video editor
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/285/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
openshot
openshot-doc
frei0r-plugins
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
openshot
openshot-doc
frei0r-plugins
</uninstall_package_names>
</app>