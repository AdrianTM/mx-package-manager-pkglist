<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Catalan
</name>

<description>  
Catalan Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-ca
myspell-ca
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-ca
myspell-ca
</uninstall_package_names>
</app>