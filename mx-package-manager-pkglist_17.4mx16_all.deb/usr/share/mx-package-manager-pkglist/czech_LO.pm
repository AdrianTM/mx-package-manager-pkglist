<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Czech_Libreoffice
</name>

<description>  
Czech LibreOffice Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
libreoffice-draw     
libreoffice-impress 
libreoffice-math
libreoffice-writer
libreoffice-l10n-cs
libreoffice-help-cs 
libreoffice-gtk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
libreoffice-draw     
libreoffice-impress 
libreoffice-math
libreoffice-writer
libreoffice-l10n-cs
libreoffice-help-cs 
libreoffice-gtk
</uninstall_package_names>
</app>