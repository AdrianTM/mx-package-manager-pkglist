<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Vietnamese_Input
</name>

<description>  
Vietnamese Fonts and ibus
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
im-switch
        ibus-unikey 
        ibus-table-viqr 
        ibus-gtk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
im-switch
        ibus-unikey 
        ibus-table-viqr  
        ibus-gtk
</uninstall_package_names>
</app>