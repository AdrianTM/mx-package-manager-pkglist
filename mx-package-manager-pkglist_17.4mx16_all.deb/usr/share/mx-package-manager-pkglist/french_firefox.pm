<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
French_Firefox
</name>

<description>  
French localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-fr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-fr
</uninstall_package_names>
</app>