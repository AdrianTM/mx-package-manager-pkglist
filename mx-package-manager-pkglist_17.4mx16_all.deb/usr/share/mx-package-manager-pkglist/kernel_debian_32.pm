<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
Debian 32 bit no-pae
</name>

<description>  
Default Debian 3.16 32bit linux kernel, no-PAE, single core
</description>

<installable>
32
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-3.16.0-4-586
linux-headers-3.16.0-4-586
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-3.16.0-4-586
linux-headers-3.16.0-4-586
</uninstall_package_names>
</app>