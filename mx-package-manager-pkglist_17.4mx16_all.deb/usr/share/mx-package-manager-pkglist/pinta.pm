<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>  
Pinta
</name>

<description>  
A Simple Paint Program
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/466/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
pinta
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pinta
</uninstall_package_names>
</app>