<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Lithuanian_Thunderbird
</name>

<description>  
Lithuanian localisation of Thunderbird
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-xpi-lt
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-xpi-lt
</uninstall_package_names>
</app>