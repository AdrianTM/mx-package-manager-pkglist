<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Japanese_Firefox
</name>

<description>  
Japanese localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-ja
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-ja
</uninstall_package_names>
</app>