<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>  
Guayadeque
</name>

<description>  
a music management program designed for all music enthusiasts
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/661/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
guayadeque
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
guayadeque
</uninstall_package_names>
</app>