<?xml version="1.0"?>
<app>

<category>
FileManagers
</category>

<name>  
PCManFM
</name>

<description>  
a fast and lightweight file manager
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/678/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
pcmanfm
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pcmanfm
</uninstall_package_names>
</app>