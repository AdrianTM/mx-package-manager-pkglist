<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Romanian_Firfox
</name>

<description>  
Romanian localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-ro
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-ro
</uninstall_package_names>
</app>