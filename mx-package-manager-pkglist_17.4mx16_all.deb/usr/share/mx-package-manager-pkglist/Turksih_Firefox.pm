<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Turkish_Firefox
</name>

<description>  
Turkish localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-tr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-tr 
</uninstall_package_names>
</app>