<?xml version="1.0"?>
<app>

<category>
Network
</category>

<name>  
Tor and Privoxy
</name>

<description>  
Tor and Privoxy
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
tor
privoxy
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
tor
privoxy
</uninstall_package_names>
</app>