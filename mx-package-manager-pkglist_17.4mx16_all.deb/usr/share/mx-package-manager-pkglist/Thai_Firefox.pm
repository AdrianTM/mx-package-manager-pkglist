<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Thai_Firefox
</name>

<description>  
Thai localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-th
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-th 
</uninstall_package_names>
</app>