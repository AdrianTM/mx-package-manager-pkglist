<?xml version="1.0"?>
<app>

<category>
Docks
</category>

<name>  
Docky
</name>

<description>  
Elegant, Clean, Powerful Dock
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/004/689/thumb.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
docky
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
docky
</uninstall_package_names>
</app>