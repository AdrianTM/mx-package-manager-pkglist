<?xml version="1.0"?>
<app>

<category>
Remote Access
</category>

<name>  
x11vnc
</name>

<description>  
VNC server for X window environments
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
x11vnc
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
x11vnc
</uninstall_package_names>
</app>